// Links
const INSTAGRAM_URL = 'https://www.instagram.com/kaminart_kh';

// Common
const LOGO = 'KaminArt';

// Contacts
const TEL = '+380503009903';
const EMAIL = 'info@kaminart.com.ua';
const INSTAGRAM = 'KaminArt_kh';

export { INSTAGRAM_URL, LOGO, TEL, EMAIL, INSTAGRAM };
