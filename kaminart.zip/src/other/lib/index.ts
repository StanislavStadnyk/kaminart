import BackToTop from './BackToTop/BackToTop';

export { BackToTop };
